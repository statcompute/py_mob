# py_mob/__init__.py

__version__ = "0.2.2"

from .py_mob import *
